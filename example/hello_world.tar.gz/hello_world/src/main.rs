extern crate libc;

fn main() {
  println!("Hello World!");
}
